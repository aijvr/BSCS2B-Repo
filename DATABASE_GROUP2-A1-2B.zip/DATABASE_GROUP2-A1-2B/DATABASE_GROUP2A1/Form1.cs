﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DATABASE_GROUP2A1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection conn = new SqlConnection("Data Source=DESKTOP-85OTM7C\\SQLEXPRESS;Initial Catalog=group2db;Integrated Security=True");

        private void button1_Click(object sender, EventArgs e)
        {
            
            conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO STUDENTS values ('" + int.Parse(textBox1.Text) + "','" + textBox2.Text + "', '" + textBox3.Text + "','" + int.Parse(textBox4.Text) + "')", conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            showtable();
            MessageBox.Show("Successfully Inserted!");

            
        }

        void showtable()
        {
            SqlCommand command = new SqlCommand("SELECT * FROM STUDENTS", conn);
            SqlDataAdapter sda = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            showtable();
        }



        private void button2_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmmd = new SqlCommand("UPDATE STUDENTS SET Name='" + textBox2.Text + "', Course='" + textBox3.Text + "', Age='" + int.Parse(textBox4.Text) + "' WHERE ID='" + int.Parse(textBox1.Text) + "'", conn);
            cmmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Successfully Updated!");
            showtable();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand cmnd = new SqlCommand("DELETE FROM STUDENTS WHERE ID = '" + int.Parse(textBox1.Text) + "'", conn);
            cmnd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Successfully Deleted!");
            showtable();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            populateGrid();
        }

        public void populateGrid()
        {
            conn.Open();
            string querry = "SELECT * FROM STUDENTS WHERE ID = '" + int.Parse(textBox1.Text) + "'";
            SqlDataAdapter Db = new SqlDataAdapter(querry, conn);
            SqlCommandBuilder builder = new SqlCommandBuilder(Db);
            var ds = new DataSet();
            Db.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            conn.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
        }
    }
}
